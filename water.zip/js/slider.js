// var mySwiper = new Swiper('.slider', {
//   speed: 400,
//   spaceBetween: 100
// });

var sliderProduct = new Swiper('.slider-product', {
  navigation: {
    nextEl: '.button-next',
    prevEl: '.button-prev',
  },
});

var sliderFeedback = new Swiper('.slider-feedback', {
  navigation: {
    nextEl: '.button-Next',
    prevEl: '.button-Prev',
  },
});